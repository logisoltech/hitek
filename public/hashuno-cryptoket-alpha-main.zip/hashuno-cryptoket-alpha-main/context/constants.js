import market from './NFTMarketplace.json';

export const MarketAddress = '0xc9f6CE5711508d1D29AF139F374fEDF6365Bc520';
export const MarketAddressABI = market.abi;
